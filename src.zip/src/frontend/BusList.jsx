<>
  <meta charSet="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Bus List</title>
  <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"
  />
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css"
    rel="stylesheet"
    integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC"
    crossOrigin="anonymous"
  />
  <link rel="stylesheet" href="BusList.css" />
  <nav className="navbar navbar-expand-sm bg-light navbar-light sticky-top">
    <div className="container-fluid">
      <a className="navbar-brand" href="#">
        <span className="navbarText">Grab your favourite bus !</span>
      </a>
      <a href="home.html">
        <img src="busListHome.png" alt="home" className="homeIcon" />
      </a>
    </div>
  </nav>
  <div className="container-fluid m-3 whole">
    <div className="section">
      <div className="d-flex Row">
        <div className="flex-fill busImage">
          <img src="school-bus.gif" alt="bus icon" className="bus-pic" />
        </div>
        <div className="flex-fill details1">
          <p className="name">Royal travels</p>
          <p className="AC">AC</p>
          <span className="fa fa-star checked" />
          <span className="fa fa-star checked" />
          <span className="fa fa-star checked" />
          <span className="fa fa-star checked" />
          <span className="fa fa-star" />
        </div>
        <div className="flex-fill details2">
          <p className="time">
            11:30 <span>→</span> 14:00
          </p>
          <img src="pocket-watch.gif" alt="time" className="watch" />
          <p className="btn btn-outline-dark mt-3">2 hrs 30 min</p>
        </div>
        <div className="flex-fill details3">
          <span className="badge rounded-pill">10 seats available</span>
          <p className="cost">
            <span>₹</span> 220
          </p>
          <button
            className="selectButton"
            onclick="document.location='seat.html'"
          >
            Select seats
          </button>
        </div>
        <div className="flex-fill busImage">
          <img src="passengerDark.png" alt="seats" className="seatPic" />
        </div>
      </div>
    </div>
    <div className="section">
      <div className="d-flex Row">
        <div className="flex-fill busImage">
          <img src="school-bus.gif" alt="bus icon" className="bus-pic" />
        </div>
        <div className="flex-fill details1">
          <p className="name">Rockstar Journey</p>
          <p className="AC">Non AC</p>
          <span className="fa fa-star checked" />
          <span className="fa fa-star checked" />
          <span className="fa fa-star" />
          <span className="fa fa-star" />
          <span className="fa fa-star" />
        </div>
        <div className="flex-fill details2">
          <p className="time">
            13:40 <span>→</span> 15:40
          </p>
          <img src="pocket-watch.gif" alt="time" className="watch" />
          <p className="btn btn-outline-dark mt-3">2 hrs</p>
        </div>
        <div className="flex-fill details3">
          <span className="badge rounded-pill">26 seats available</span>
          <p className="cost">
            <span>₹</span> 320
          </p>
          <button
            className="selectButton"
            onclick="document.location='seat.html'"
          >
            Select seats
          </button>
        </div>
        <div className="flex-fill busImage">
          <img src="passengerDark.png" alt="seats" className="seatPic" />
        </div>
      </div>
    </div>
    <div className="section">
      <div className="d-flex Row">
        <div className="flex-fill busImage">
          <img src="school-bus.gif" alt="bus icon" className="bus-pic" />
        </div>
        <div className="flex-fill details1">
          <p className="name">Deluxe Plus</p>
          <p className="AC">AC</p>
          <span className="fa fa-star checked" />
          <span className="fa fa-star checked" />
          <span className="fa fa-star checked" />
          <span className="fa fa-star checked" />
          <span className="fa fa-star" />
        </div>
        <div className="flex-fill details2">
          <p className="time">
            11:00 <span>→</span> 12:40
          </p>
          <img src="pocket-watch.gif" alt="time" className="watch" />
          <p className="btn btn-outline-dark mt-3">1 hr 40 min</p>
        </div>
        <div className="flex-fill details3">
          <span className="badge rounded-pill">20 seats available</span>
          <p className="cost">
            <span>₹</span> 250
          </p>
          <button
            className="selectButton"
            onclick="document.location='seat.html'"
          >
            Select seats
          </button>
        </div>
        <div className="flex-fill busImage">
          <img src="passengerDark.png" alt="seats" className="seatPic" />
        </div>
      </div>
    </div>
    <div className="section">
      <div className="d-flex Row">
        <div className="flex-fill busImage">
          <img src="school-bus.gif" alt="bus icon" className="bus-pic" />
        </div>
        <div className="flex-fill details1">
          <p className="name">Wonder Travels</p>
          <p className="AC">Non AC</p>
          <span className="fa fa-star checked" />
          <span className="fa fa-star checked" />
          <span className="fa fa-star" />
          <span className="fa fa-star" />
          <span className="fa fa-star" />
        </div>
        <div className="flex-fill details2">
          <p className="time">
            10:10 <span>→</span> 13:20
          </p>
          <img src="pocket-watch.gif" alt="time" className="watch" />
          <p className="btn btn-outline-dark mt-3">3 hrs 10 min</p>
        </div>
        <div className="flex-fill details3">
          <span className="badge rounded-pill">5 seats available</span>
          <p className="cost">
            <span>₹</span> 260
          </p>
          <button
            className="selectButton"
            onclick="document.location='seat.html'"
          >
            Select seats
          </button>
        </div>
        <div className="flex-fill busImage">
          <img src="passengerDark.png" alt="seats" className="seatPic" />
        </div>
      </div>
    </div>
  </div>
</>
