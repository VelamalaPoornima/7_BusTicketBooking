<>
  <meta charSet="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Document</title>
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
    rel="stylesheet"
  />
  <style
    dangerouslySetInnerHTML={{
      __html:
        "\n        .nav-item :hover{\n            color: aliceblue;\n            text-decoration: underline;\n        }\n        .container{\n            display: flex;\n            justify-content: space-between;\n        }\n        .pic{\n            border-radius: 40%;\n            height: 280px;\n            width: 220px;\n            border: solid 2px;\n        }\n        .text{\n            margin-top: 60px;\n            margin-left: 10px;\n            margin-bottom: 15px;\n        }\n        .name{\n            text-align: center;\n        }\n    "
    }}
  />
  <nav className="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div className="container-fluid">
      <a className="navbar-brand fw-bold">VOYAGE</a>
      <div
        className="collapse navbar-collapse justify-content-end"
        id="navbarNav"
      >
        <ul className="navbar-nav">
          <li className="nav-item">
            <a className="nav-link fw-bold" href="home.html">
              Home
            </a>
          </li>
          <li className="nav-item">
            <a className="nav-link fw-bold" href="Offers.html">
              Offers
            </a>
          </li>
          <li className="nav-item">
            <a className="nav-link fw-bold" href="FAQ.html">
              FAQs
            </a>
          </li>
          <li className="nav-item">
            <a className="nav-link fw-bold" href="SignIn.html">
              Login
            </a>
          </li>
          <li className="nav-item">
            <a className="nav-link fw-bold" href="Register.html">
              Sign Up
            </a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <div className="main">
    <h2 className="text">About us</h2>
    <p className="m-3">
      Welcome to Voyage! We are dedicated to providing you with a seamless and
      convenient bus booking experience. Our mission is to connect travelers
      with reliable bus services, making travel accessible to everyone.
    </p>
    <p className="m-3">
      At Bus Booking, we prioritize safety, comfort, and affordability. Whether
      you're planning a short trip or a long journey, we've got you covered with
      a wide range of bus routes and schedules to choose from.
    </p>
    <p className="m-3">
      Our user-friendly platform allows you to easily search, compare, and book
      bus tickets online. With secure payment options and 24/7 customer support,
      we strive to ensure that your travel plans go smoothly from start to
      finish.
    </p>
    <p className="m-3">
      Thank you for choosing Voyage for your travel needs. We look forward to
      serving you!
    </p>
  </div>
  <h2 className="text">Management Team</h2>
  <div className="container">
    <div>
      <img src="Jenica.jpg" className="pic" />
      <div className="name">Jenica</div>
    </div>
    <div>
      <img src="Poornima.jpg" className="pic" />
      <div className="name">Poornima</div>
    </div>
    <div>
      <img src="Shreya.jpg" className="pic" />
      <div className="name">Shreya</div>
    </div>
  </div>
</>
