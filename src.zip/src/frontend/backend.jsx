import React from 'react';
import { BrowserRouter as Router, Route, Switch, Link } from 'react-router-dom';

// Contact Modal Component
const ContactModal = () => {
  return (
    <div className="offcanvas offcanvas-start" id="canvas">
      <div className="offcanvas-header">
        <h1 className="canva-heading">Contact Us</h1>
        <button type="button" className="btn-close" data-bs-dismiss="offcanvas"></button>
      </div>
      <div className="offcanvas-body text-secondary">
        <h4><img src="icons8-phone-50.png" className="icon" alt="phone"/>9188169265</h4>
        <h4><img src="icons8-phone-50.png" className="icon" alt="phone"/>8587643210</h4>
        <h4><img src="icons8-mail-48.png" className="icon" alt="email"/><a href="mailto:voyage@gmail.com" className="text-secondary">voyage@gmail.com</a></h4>
        <h4><img src="icons8-insta-48.png" className="icon" alt="instagram"/>voyage_2006</h4>
        <h4><img src="icons8-facebook-48.png" className="icon" alt="facebook"/>tickets.voyage.2006</h4>
        <h4><img src="icons8-twitterx-30.png" className="icon" alt="twitter"/>voyage_bus</h4>
      </div>
    </div>
  );
};

// Header Component
const Header = () => {
  return (
    <div className='header'>
      <div className="logo">
        <h2>VOYAGE</h2>
      </div>
      <nav>
        <ul>
          <li><Link to="/about">About</Link></li>
          <li><button className="canva-btn" data-bs-toggle="offcanvas" data-bs-target="#canvas"><Link to="#">Contact</Link></button></li>
          <li><Link to="/faq">FAQs</Link></li>
          <li><Link to="/offers">Offers</Link></li>
        </ul>
      </nav>
      <div className="user-actions">
        <Link to="/signin"><button className="btn btn-light">Login</button></Link>
        <Link to="/register"><button className="btn btn-light">Sign Up</button></Link>
      </div>
    </div>
  );
};

// Home Page Component
const HomePage = () => {
  return (
    <div className="mx-auto main">
      <h3 className="journey">WILD JOURNEY AWAITS!</h3>
      <div className="book-btn">
        <button type="button" className="btn btn-outline-light book" data-bs-toggle="modal" data-bs-target="#SignModal">Book Tickets</button>
      </div>
    </div>
  );
};

// Sign In Page Component
const SignInPage = () => {
  return (
    <div className="modal fade" id="SignModal">
      <div className="modal-dialog modal-dialog-centered">
        <div className="modal-content">
          <div className="modal-body">
            <div className="ourclose">
              <button type="button" className="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <h4>Kindly Login to Continue</h4>
            <button type="button" className="modal-btn" onClick={() => window.location.href = 'signIn.html'}>Sign In</button>
          </div>
        </div>
      </div>
    </div>
  );
};

// App Component
const App = () => {
  return (
    <Router>
      <Header />
      <Switch>
        <Route path="/" exact component={HomePage} />
        <Route path="/about" component={AboutPage} />
        <Route path="/faq" component={FAQPage} />
        <Route path="/offers" component={OffersPage} />
        <Route path="/signin" component={SignInPage} />
        <Route path="/register" component={RegisterPage} />
      </Switch>
      <ContactModal />
    </Router>
  );
};

export default App;