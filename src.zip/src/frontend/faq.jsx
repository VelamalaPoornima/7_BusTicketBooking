<>
  <meta charSet="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>FAQ</title>
  <link
    rel="stylesheet"
    href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
  />
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css"
    rel="stylesheet"
  />
  <style
    dangerouslySetInnerHTML={{
      __html:
        "\n        body {\n            background: url(faqf.webp);\n            background-repeat: no-repeat;\n            background-size: cover;\n            font-family: Arial, sans-serif;\n            margin: 0;\n            padding: 0;\n        }\n        main {\n            padding: 20px;\n            display: flex;\n        }\n        \n        section {\n            flex-basis: 45%;\n            margin: 10px;\n            padding: 80px;\n            border: 1px solid #ccc;\n            border-radius: 4px;\n        }\n        \n        section h2 {\n            font-size: 1.5em;\n            margin-bottom: 20px;\n        }\n        \n        .nav-item:hover{\n            color: white;\n            text-decoration: underline;\n        }\n        \n        .faq-item{\n            margin-bottom: 20px;\n        }\n        .faq-question{\n            cursor: pointer;\n            color: rgb(0, 0, 0);\n        }\n        .faq-answer {\n            display: none;\n            color:rgb(47, 0, 61);\n        }\n        .faq-answer.show {\n            display:block;\n        }\n    "
    }}
  />
  <nav className="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div className="container-fluid">
      <a className="navbar-brand fw-bold">VOYAGE</a>
      <div
        className="collapse navbar-collapse justify-content-end"
        id="navbarNav"
      >
        <ul className="navbar-nav">
          <li className="nav-item">
            <a className="nav-link fw-bold" href="home.html">
              Home
            </a>
          </li>
          <li className="nav-item">
            <a className="nav-link fw-bold" href="About.html">
              About
            </a>
          </li>
          <li className="nav-item">
            <a className="nav-link fw-bold" href="Offers.html">
              Offers
            </a>
          </li>
          <li className="nav-item">
            <a className="nav-link fw-bold" href="SignIn.html">
              Login
            </a>
          </li>
          <li className="nav-item">
            <a className="nav-link fw-bold" href="Register.html">
              Sign Up
            </a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <main>
    <section className="popular-topics">
      <h2>Popular Questions</h2>
      <hr />
      <div className="faq-item">
        <h5 className="faq-question" onclick="toggleAnswer(1)">
          <i className="bi bi-chevron-right" /> How do I book a bus ticket?
        </h5>
        <p className="faq-answer" id="answer1">
          To book a bus ticket, simply visit our website, select your desired
          origin and destination, choose your travel date, enter the number of
          passengers, and click on the 'Submit' button. Follow the on-screen
          instructions to complete the booking process.
        </p>
      </div>
      <hr />
      <div className="faq-item">
        <h5 className="faq-question" onclick="toggleAnswer(2)">
          <i className="bi bi-chevron-right" /> Can I cancel my bus ticket?
        </h5>
        <p className="faq-answer" id="answer2">
          Yes, you can cancel your bus ticket depending on the cancellation
          policy of the bus operator.
        </p>
      </div>
      <hr />
      <div className="faq-item">
        <h5 className="faq-question" onclick="toggleAnswer(3)">
          <i className="bi bi-chevron-right" /> How can I pay for my bus ticket?
        </h5>
        <p className="faq-answer" id="answer3">
          We accept various payment methods including credit/debit cards, net
          banking, and mobile wallets. You can choose your preferred payment
          option during the booking process.
        </p>
      </div>
      <hr />
      <div className="faq-item">
        <h5 className="faq-question" onclick="toggleAnswer(4)">
          <i className="bi bi-chevron-right" /> What should I do if I face any
          issues during booking?
        </h5>
        <p className="faq-answer" id="answer4">
          If you encounter any issues during the booking process, please contact
          our customer support team for assistance. You can reach us via email,
          phone.{" "}
        </p>
      </div>
      <hr />
    </section>
    <section className="faqs">
      <h2>FAQs about Voyage</h2>
      <hr />
      <div className="faq-item">
        <h5 className="faq-question" onclick="toggleAnswer(5)">
          <i className="bi bi-chevron-right" /> Does booking online cost me
          more?
        </h5>
        <p className="faq-answer" id="answer5">
          Not at all! The price of the bus ticket is the same as you would get
          from the bus operator too.The price is the same or sometimes
          discounted depending on the season/time.
        </p>
      </div>
      <hr />
      <div className="faq-item">
        <h5 className="faq-question" onclick="toggleAnswer(6)">
          <i className="bi bi-chevron-right" /> Do I need to register to use
          redBus?
        </h5>
        <p className="faq-answer" id="answer6">
          Yes. You need to login to book a ticket
        </p>
      </div>
      <hr />
      <div className="faq-item">
        <h5 className="faq-question" onclick="toggleAnswer(7)">
          <i className="bi bi-chevron-right" /> How many hours before we can
          cancel bus ticket?
        </h5>
        <p className="faq-answer" id="answer7">
          up to One (1) hour before the scheduled departure of the bus service
          from the Origin Point.{" "}
        </p>
      </div>
      <hr />
    </section>
  </main>
</>
