<>
  <meta charSet="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Bus Ticket Booking</title>
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
    rel="stylesheet"
  />
  <link rel="stylesheet" href="home.css" />
  <div className="offcanvas offcanvas-start" id="canvas">
    <div className="offcanvas-header">
      <h1 className="canva-heading">Contact Us</h1>
      <button type="button" className="btn-close" data-bs-dismiss="offcanvas" />
    </div>
    <div className="offcanvas-body text-secondary">
      <h4>
        <img src="icons8-phone-50.png" className="icon" />
        9188169265
      </h4>
      <h4>
        <img src="icons8-phone-50.png" className="icon" />
        8587643210
      </h4>
      <h4>
        <img src="icons8-mail-48.png" className="icon" />
        <a href="mailto:voyage@gmail.com" className="text-secondary">
          voyage@gmail.com
        </a>
      </h4>
      <h4>
        <img src="icons8-insta-48.png" className="icon" />
        voyage_2006
      </h4>
      <h4>
        <img src="icons8-facebook-48.png" className="icon" />
        tickets.voyage.2006
      </h4>
      <h4>
        <img src="icons8-twitterx-30.png" className="icon" />
        voyage_bus
      </h4>
    </div>
  </div>
  <div className="header">
    <div className="logo">
      <h2>VOYAGE</h2>
    </div>
    <nav>
      <ul>
        <li>
          <a href="About.html">About</a>
        </li>
        <li>
          <button
            className="canva-btn"
            data-bs-toggle="offcanvas"
            data-bs-target="#canvas"
          >
            <a href="#">Contact</a>
          </button>
        </li>
        <li>
          <a href="FAQ.html">FAQs</a>
        </li>
        <li>
          <a href="Offers.html">Offers</a>
        </li>
      </ul>
    </nav>
    <div className="user-actions">
      <a href="signIn.html">
        <button className="btn btn-light">Login</button>
      </a>
      <a href="Register.html">
        <button className="btn btn-light">Sign Up</button>
      </a>
    </div>
  </div>
  <div className="mx-auto main">
    <h3 className="journey">WILD JOURNEY AWAITS!</h3>
    <div className="book-btn">
      <button
        type="button"
        className="btn btn-outline-light book"
        data-bs-toggle="modal"
        data-bs-target="#SignModal"
      >
        Book Tickets
      </button>
    </div>
  </div>
  <div className="modal fade" id="SignModal">
    <div className="modal-dialog modal-dialog-centered">
      <div className="modal-content">
        <div className="modal-body">
          <div className="ourclose">
            <button
              type="button"
              className="btn-close btn-close-white"
              data-bs-dismiss="modal"
            />
          </div>
          <h4>Kindly Login to Continue</h4>
          <button
            type="button"
            className="modal-btn"
            onclick="document.location='signIn.html'"
          >
            Sign In
          </button>
        </div>
      </div>
    </div>
  </div>
</>
