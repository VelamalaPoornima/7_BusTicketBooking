<>
  <meta charSet="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Offers</title>
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
    rel="stylesheet"
  />
  <style
    dangerouslySetInnerHTML={{
      __html:
        "\n    body{\n        padding-top: 10px;\n    }\n    .card-img-top {\n      height: 300px; \n      object-fit: cover; \n    }\n    .nav-item:hover{\n        color: white;\n        text-decoration: underline;\n    }\n  "
    }}
  />
  <nav className="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div className="container-fluid">
      <a className="navbar-brand fw-bold">VOYAGE</a>
      <div
        className="collapse navbar-collapse justify-content-end"
        id="navbarNav"
      >
        <ul className="navbar-nav">
          <li className="nav-item">
            <a className="nav-link fw-bold" href="home.html">
              Home
            </a>
          </li>
          <li className="nav-item">
            <a className="nav-link fw-bold" href="About.html">
              About
            </a>
          </li>
          <li className="nav-item">
            <a className="nav-link fw-bold" href="FAQ.html">
              FAQs
            </a>
          </li>
          <li className="nav-item">
            <a className="nav-link fw-bold" href="SignIn.html">
              Login
            </a>
          </li>
          <li className="nav-item">
            <a className="nav-link fw-bold" href="Register.html">
              Sign Up
            </a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <div className="container mt-5">
    <h3>Offers!</h3>
    <p>Please choose an offer to get exciting discounts</p>
    <div className="row">
      <div className="col-md-4">
        <div className="card mb-3">
          <img
            className="card-img-top"
            src="earlybirdreal.jpg"
            alt="Card image"
          />
          <div className="card-body">
            <h4 className="card-title">Early Bird Special</h4>
            <p className="card-text">
              Book your bus tickets in advance and save big! Enjoy exclusive
              discounts when you plan your trip ahead of time, ensuring a
              stress-free journey at a great price.
            </p>
          </div>
        </div>
      </div>
      <div className="col-md-4">
        <div className="card mb-3">
          <img className="card-img-top" src="ci2.jpeg" alt="Card image" />
          <div className="card-body">
            <h4 className="card-title">Weekend Getaway</h4>
            <p className="card-text">
              Make the most of your weekends with our special getaway deals!
              Whether it's a short trip to the countryside or a city escape,
              enjoy discounted fares for weekend travel and create unforgettable
              memories.
            </p>
          </div>
        </div>
      </div>
      <div className="col-md-4">
        <div className="card mb-3">
          <img className="card-img-top" src="fam.jpg" alt="Card image" />
          <div className="card-body">
            <h4 className="card-title">Family Adventure Package</h4>
            <p className="card-text">
              Traveling with the family has never been more affordable! Take
              advantage of our family package deals, offering discounted rates
              for families booking multiple tickets together. Enjoy quality time
              together without breaking the bank.
            </p>
          </div>
        </div>
      </div>
    </div>
    <div className="row">
      <div className="col-md-4">
        <div className="card mb-3">
          <img className="card-img-top" src="week3.jpg" alt="Card image" />
          <div className="card-body">
            <h4 className="card-title">Round Trip Delight</h4>
            <p className="card-text">
              Double the savings, double the fun! Book your round-trip tickets
              with us and enjoy exclusive discounts on your entire journey.
              Experience convenience and affordability in one seamless package
            </p>
          </div>
        </div>
      </div>
      <div className="col-md-4">
        <div className="card mb-3">
          <img className="card-img-top" src="download.jpg" alt="Card image" />
          <div className="card-body">
            <h4 className="card-title">Frequent Traveler Rewards</h4>
            <p className="card-text">
              Loyalty pays off with our exclusive rewards program! Earn points
              with every booking and unlock exciting discounts and perks. The
              more you travel, the more you save – it's our way of saying thank
              you for choosing us.
            </p>
          </div>
        </div>
      </div>
      <div className="col-md-4">
        <div className="card mb-3">
          <img className="card-img-top" src="early bird.jpg" alt="Card image" />
          <div className="card-body">
            <h4 className="card-title">Holiday Extravaganza</h4>
            <p className="card-text">
              Celebrate the holidays with unbeatable deals! Whether it's
              Christmas, New Year, or any festive occasion, enjoy special
              discounts and promotions when you book your bus tickets with us.
              Travel in style and savings this holiday season!
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</>
