<>
  <meta charSet="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Payment Page</title>
  <style
    dangerouslySetInnerHTML={{
      __html:
        "\n    body {\n      background-image: url('water12.jpg'); \n      background-size: cover;\n      background-position: center;\n      height: 100%;\n      margin: 0;\n      padding: 0;\n      font-family: Arial, sans-serif; \n    }\n\n    .header {\n      background-color: rgba(3, 3, 3, 0.9);\n      padding: 10px;\n      display: flex;\n      justify-content: space-between;\n      align-items: center;\n    }\n\n    .header a {\n      text-decoration: none;\n      color: #fffdfd;\n      margin-left: 10px;\n      font-weight: bold;\n      transition: text-decoration 0.3s; \n    }\n\n    .header a:hover {\n      text-decoration: underline; \n    }\n\n    .header h1 {\n      margin: 0;\n      color: #fffdfd; \n    }\n\n    .payment-container {\n      display: flex;\n      justify-content: center;\n      align-items: center;\n      height: 100vh;\n    }\n\n    .payment-box {\n      padding: 20px;\n      border: 1px solid #ccc;\n      border-radius: 10px;\n      background-color: rgba(255, 255, 255, 0.9); \n      display: flex;\n      flex-direction: column;\n      align-items: center;\n    }\n\n    .dialog {\n      display: none;\n      position: fixed;\n      top: 50%;\n      left: 50%;\n      transform: translate(-50%, -50%);\n      padding: 40px;\n      background-color: #fff; \n      border: 2px solid #2c3e50; \n      border-radius: 10px;\n      z-index: 999;\n      text-align: center;\n      color: #2c3e50; \n      font-size: 18px;\n      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);\n    }\n\n    .payment-options {\n      display: flex;\n      flex-direction: column;\n      align-items: flex-start;\n      margin-bottom: 20px;\n    }\n\n    .payment-option {\n      margin-bottom: 10px;\n      display: flex;\n      align-items: center;\n    }\n\n    .payment-option label {\n      margin-left: 10px;\n      width: 150px; \n      display: inline-block;\n    }\n\n    .payment-option img {\n      width: 50px;\n      height: 50px;\n      margin-right: 10px;\n    }\n\n    button {\n      margin-top: 20px;\n    }\n\n    #paymentSuccess {\n      display: none;\n      margin-top: 20px;\n    }\n\n    #unfilledDetailsPopup {\n      display: none;\n      background-color: rgba(255, 0, 0, 0.5);\n      color: #fff; \n      padding: 10px 20px;\n      position: fixed;\n      top: 50%;\n      left: 50%;\n      transform: translate(-50%, -50%);\n      border-radius: 5px;\n      z-index: 999;\n    }\n  "
    }}
  />
  <div className="header">
    <h1>Voyage</h1>
    <div>
      <a href="home.html">Home</a>
      <a href="About.html">About</a>
      <a href="FAQ.html">FAQs</a>
      <a href="Offers.html">Offers</a>
    </div>
  </div>
  <div className="payment-container">
    <div className="payment-box">
      <h1>Select Payment Method</h1>
      <form id="paymentForm">
        <div className="payment-options">
          <div className="payment-option">
            <img src="master-card-icon.png" alt="Card" />
            <input
              type="radio"
              id="card"
              name="paymentMethod"
              defaultValue="card"
            />
            <label htmlFor="card">Credit/Debit Card</label>
          </div>
          <div className="payment-option">
            <img src="upi-icon.png" alt="UPI" />
            <input
              type="radio"
              id="upi"
              name="paymentMethod"
              defaultValue="upi"
            />
            <label htmlFor="upi">UPI</label>
          </div>
          <div className="payment-option">
            <img src="net-banking-icon (1).png" alt="Net Banking" />
            <input
              type="radio"
              id="netbanking"
              name="paymentMethod"
              defaultValue="netbanking"
            />
            <label htmlFor="netbanking">Net Banking</label>
          </div>
        </div>
      </form>
      <button onclick="makePayment()">Make Payment</button>
      <div id="dialog" className="dialog">
        <div id="paymentDetails" />
      </div>
      <div id="cardDetails" className="dialog">
        <h2>Enter Card Details</h2>
        <label htmlFor="cardNumber">Card Number:</label>
        <input type="text" id="cardNumber" name="cardNumber" required="" />
        <br />
        <br />
        <label htmlFor="expiryMonth">Expiry Month:</label>
        <input type="text" id="expiryMonth" name="expiryMonth" required="" />
        <br />
        <br />
        <label htmlFor="cvv">CVV:</label>
        <input type="text" id="cvv" name="cvv" required="" />
        <br />
        <br />
        <label htmlFor="cardName">Name on Card:</label>
        <input type="text" id="cardName" name="cardName" required="" />
        <br />
        <br />
        <button onclick="submitCardDetails()">Submit</button>
        <button onclick="closeDialog('cardDetails')">Close</button>
      </div>
      <div id="upiDetails" className="dialog">
        <h2>Enter UPI ID</h2>
        <label htmlFor="upiID">UPI ID:</label>
        <input type="text" id="upiID" name="upiID" required="" />
        <br />
        <button onclick="verifyUpiId()">Verify and Pay</button>
        <button onclick="closeDialog('upiDetails')">Close</button>
      </div>
      <div id="netbankingDetails" className="dialog">
        <h2>Enter Net Banking Details</h2>
        <label htmlFor="accountNumber">Account Number:</label>
        <input
          type="text"
          id="accountNumber"
          name="accountNumber"
          required=""
        />
        <br />
        <br />
        <label htmlFor="ifscCode">IFSC Code:</label>
        <input type="text" id="ifscCode" name="ifscCode" required="" />
        <br />
        <br />
        <label htmlFor="accountHolderName">Account Holder's Name:</label>
        <input
          type="text"
          id="accountHolderName"
          name="accountHolderName"
          required=""
        />
        <br />
        <br />
        <button onclick="submitNetbankingDetails()">Make Payment</button>
        <button onclick="closeDialog('netbankingDetails')">Close</button>
      </div>
      <div id="paymentSuccess" className="dialog">
        Payment Successful!
      </div>
      <div id="unfilledDetailsPopup" className="dialog">
        Please fill in all the details.
      </div>
    </div>
  </div>
</>
