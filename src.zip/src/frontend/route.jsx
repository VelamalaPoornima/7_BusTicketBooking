<>
  <meta charSet="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Route</title>
  <link
    rel="stylesheet"
    href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"
  />
  <link
    href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css"
    rel="stylesheet"
  />
  <style
    dangerouslySetInnerHTML={{
      __html:
        "\n        body {\n            background: url(logoo.webp);\n            background-repeat: no-repeat;\n            background-size: cover;\n        }\n        .nav-item:hover{\n            color: white;\n            text-decoration: underline;\n        }\n        .para{\n            text-align: center;\n            border: solid 2px black;\n            width: 40%;\n            height: 20%;\n            border-style: dashed;\n            border-radius: 5%;\n            margin-left: 27%;\n            padding-top: 10px;\n            color: rgb(5, 1, 1);\n            letter-spacing: 1px;\n            font-family: cursive;\n            font-size: large;\n            margin-bottom: 50px;\n            margin-top: 120px;\n        }\n        #second {\n            margin-top:10px;\n            border: 1px solid;\n            box-shadow: 5px 5px 5px 3px;\n            background-color: rgba(2, 29, 50, 0.3);\n            border-width: 80%;\n            height: 80%;\n            margin-bottom: 0px;\n        }\n        .drop {\n            color: black;\n            width: 30%;\n            height: 40px;\n            font-size: 1.3em;\n            margin-bottom: 20px;\n            margin-right: 1.2%;\n            margin-left: 1.2%;\n            background-color: rgb(203, 228, 225)\n        }\n        .tabshead {\n            font-weight: bold;\n            font-size: 1.5em;\n            color: rgb(27, 114, 200);\n        }\n        .lab {\n            color: aliceblue;\n            padding-top: 15px;\n            padding-bottom: 15px;\n        }\n        .sub {\n            background-color: aliceblue;\n            border: none;\n            color: #000000; \n            padding: 10px;\n            border-radius: 4px;\n            font-size: large;\n            margin-bottom: 5px;\n        } \n        .cont{\n            margin-top: 0px;\n            padding: 90px;\n            max-width: 800px;\n            color: #fff;\n            text-align:center;\n        }\n        .icon{\n            color: white;\n        }\n    "
    }}
  />
  <nav className="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div className="container-fluid">
      <a className="navbar-brand fw-bold">VOYAGE</a>
      <div
        className="collapse navbar-collapse justify-content-end"
        id="navbarNav"
      >
        <ul className="navbar-nav">
          <li className="nav-item">
            <a className="nav-link fw-bold" href="home.html">
              Home
            </a>
          </li>
          <li className="nav-item">
            <a className="nav-link fw-bold" href="About.html">
              About
            </a>
          </li>
          <li className="nav-item">
            <a className="nav-link fw-bold" href="Offers.html">
              Offers
            </a>
          </li>
          <li className="nav-item">
            <a className="nav-link fw-bold" href="SignIn.html">
              Login
            </a>
          </li>
          <li className="nav-item">
            <a className="nav-link fw-bold" href="Register.html">
              Sign Up
            </a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <div className="para">
    <p>
      <b> Start Your experience </b>
    </p>
  </div>
  <div className="container" id="second">
    <ul className="nav nav-tabs">
      <li className="nav-item">
        <a
          className="nav-link active tabshead"
          aria-current="page"
          href="#menu1"
        >
          <i className="bi bi-bus-front" /> Bus
        </a>
      </li>
    </ul>
    <div className="tab-content">
      <div
        className="tab-pane fade show active"
        id="home"
        role="tabpanel"
        aria-labelledby="home-tab"
      >
        <div id="menu1">
          <h3 className="lab">Buses</h3>
          <form>
            <select name="origin" className="drop" id="from">
              <option value="From">From</option>
              <option value="Mumbai">Mumbai</option>
              <option value="Chennai">Chennai</option>
              <option value="Kolkata">Kolkata</option>
              <option value="Tamil_Nadu">Tamil Nadu</option>
              <option value="Hyderabad">Hyderabad</option>
              <option value="Andhra">Andhra Pradesh</option>
              <option value="Kerala">Kerala</option>
            </select>
            <i className="bi bi-arrow-left-right icon" />
            <select name="destination" className="drop" id="to">
              <option value="Origin">To</option>
              <option value="Mumbai">Mumbai</option>
              <option value="Chennai">Chennai</option>
              <option value="Kolkata">Kolkata</option>
              <option value="Tamil_Nadu">Tamil Nadu</option>
              <option value="Hyderabad">Hyderabad</option>
              <option value="Andhra">Andhra Pradesh</option>
              <option value="Kerala">Kerala</option>
            </select>
            <br />
            <input
              type="number"
              className="drop"
              min={1}
              max={10}
              placeholder="Number of passengers"
            />
            <input type="date" className="drop" />
            <br />
            <center>
              <button type="button" className="sub" onclick="listpage();">
                Book Tickets
              </button>{" "}
            </center>
          </form>
        </div>
      </div>
    </div>
  </div>
  <div className="cont">
    <p>© 2006 Voyage. All rights reserved.</p>
  </div>
</>
