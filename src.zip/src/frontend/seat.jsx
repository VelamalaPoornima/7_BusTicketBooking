<>
  <meta charSet="UTF-8" />
  <meta httpEquiv="X-UA-Compatible" content="IE=edge" />
  <meta
    name="viewport"
    content="width=device-width, initial-scale=1.0, maximum-scale=1"
  />
  <link rel="stylesheet" href="Seat.css" />
  <title>Bus Seat Booking</title>
  <div className="bus-container">
    <label> Select a bus:</label>
    <select id="bus">
      <option value={220}>Royal Travels - ₹ 220</option>
      <option value={320}>Rockstar Journey - ₹ 320</option>
      <option value={250}>Deluxe Plus - ₹ 250</option>
      <option value={260}>Wonder Travels - ₹ 260</option>
    </select>
    <a href="home.html">
      <img src="home.png" alt="home" className="homeIcon" />
    </a>
  </div>
  <ul className="showcase">
    <li>
      <div className="seat" />
      <small>Available</small>
    </li>
    <li>
      <div className="seat selected" />
      <small>Selected</small>
    </li>
    <li>
      <div className="seat sold" />
      <small>Sold</small>
    </li>
  </ul>
  <div className="container">
    <div className="row">
      <div className="seat" />
      <div className="seat" />
      <div className="space" />
      <div className="seat" />
      <div className="seat" />
    </div>
    <div className="row">
      <div className="seat" />
      <div className="seat sold" />
      <div className="space" />
      <div className="seat" />
      <div className="seat" />
    </div>
    <div className="row">
      <div className="seat" />
      <div className="seat" />
      <div className="space" />
      <div className="seat sold" />
      <div className="seat sold" />
    </div>
    <div className="row">
      <div className="seat" />
      <div className="seat" />
      <div className="space" />
      <div className="seat" />
      <div className="seat" />
    </div>
    <div className="row">
      <div className="seat" />
      <div className="seat" />
      <div className="space" />
      <div className="seat" />
      <div className="seat sold" />
    </div>
    <div className="row">
      <div className="seat" />
      <div className="seat" />
      <div className="space" />
      <div className="seat sold" />
      <div className="seat" />
    </div>
    <div className="row">
      <div className="seat" />
      <div className="seat" />
      <div className="seat" />
      <div className="seat" />
      <div className="seat sold" />
      <div className="seat" />
    </div>
  </div>
  <p className="text">
    You have selected <span id="count">0</span> seat for a price of Rs.
    <span id="total">0</span>
    <button type="button" className="paymentBtn" onclick="paymentPage()">
      Proceed to Payment
    </button>
  </p>
</>
